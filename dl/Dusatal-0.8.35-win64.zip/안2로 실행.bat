@echo off
start "" "%~dp0Dusatal.exe" -story-b
